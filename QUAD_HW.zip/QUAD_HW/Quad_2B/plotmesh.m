% by Marco Pingaro & Paolo Venini

function plotmesh(element,coordinates)

trimesh(element,coordinates(:,1),coordinates(:,2),'color','g')

return
